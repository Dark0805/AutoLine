<!DOCTYPE html>
<html lang="pt-br">

<head>

    <meta charset="UTF-8">

    <title>Área do Funcionário</title>

    <style>

        body {
            background-color: #d6d6d6;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            color: #333;
        }

        .topo {
            background-color: #333;
            color: white;
            padding: 20px 40px;
            border-bottom: 5px solid #e87500;
            position: relative;
        }

        .sair {
            position: absolute;
            right: 40px;
            top: 20px;
            padding: 9px 20px;
            background-color: #e87500;
            color: white;
            text-decoration: none;
            border-radius: 3px;
        }

        .sair:hover {
            background-color: #cf6700;
        }

        .menu {
            width: 850px;
            max-width: 90%;
            margin: 40px auto 30px;
            background-color: white;
            padding: 20px;
            box-sizing: border-box;
            box-shadow: 0 2px 8px #999;
            border-top: 4px solid #e87500;
            text-align: center;
        }

        .botao {
            padding: 10px 20px;
            margin: 5px;
            background-color: #e87500;
            color: white;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            font-size: 15px;
        }

        .botao:hover {
            background-color: #cf6700;
        }

        .caixa {
            background-color: white;
            padding: 30px;
            width: 850px;
            max-width: 90%;
            margin: 30px auto;
            box-sizing: border-box;
            box-shadow: 0 2px 8px #999;
            border-top: 4px solid #e87500;
        }

        h2 {
            margin-top: 0;
            color: #333;
            margin-bottom: 25px;
        }

        label {
            display: block;
            margin-top: 15px;
            margin-bottom: 5px;
            color: #333;
        }

        input,
        textarea,
        select {
            width: 100%;
            padding: 9px;
            box-sizing: border-box;
            border: 1px solid #aaa;
            border-radius: 3px;
        }

        textarea {
            height: 100px;
            resize: vertical;
        }

        input:focus,
        textarea:focus,
        select:focus {
            outline: none;
            border-color: #e87500;
        }

        .formulario .botao {
            width: 100%;
            margin-top: 25px;
        }

        .sucesso {
            width: 850px;
            max-width: 90%;
            margin: 20px auto;
            padding: 12px;
            box-sizing: border-box;
            background-color: #e8f5e9;
            border-left: 4px solid #4caf50;
            color: #333;
        }

        .tabela-container {
            width: 100%;
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background-color: white;
        }

        th {
            background-color: #333;
            color: white;
        }

        th,
        td {
            border: 1px solid #aaa;
            padding: 10px;
            text-align: left;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .cadastro-completo {
            width: 100%;
            overflow-x: auto;
        }

        .acompanhamento input,
        .acompanhamento select {
            width: 100%;
            box-sizing: border-box;
        }

    </style>

</head>

<body>


<?php

require_once "conexao.php";

?>


<div class="topo">

    <h1>Área do Funcionário</h1>

    <a href="login.php" class="sair">Sair</a>

</div>


<div class="menu">

    <form method="POST">

        <button type="submit"
                name="acao"
                value="clientes"
                class="botao">

            Clientes

        </button>


        <button type="submit"
                name="acao"
                value="carros"
                class="botao">

            Carros

        </button>


        <button type="submit"
                name="acao"
                value="avarias"
                class="botao">

            Avarias

        </button>


        <button type="submit"
                name="acao"
                value="cadcompleto"
                class="botao">

            Cadastro completo

        </button>


        <button type="submit"
                name="acao"
                value="acompanhamento"
                class="botao">

            Acompanhamento

        </button>

    </form>

</div>


<?php


/* =======================================================
   CADASTRO DE CLIENTE
   ======================================================= */

if (isset($_POST["cadastrar_cliente"])) {

    $nome = $_POST["nome"];
    $cpf = $_POST["cpf"];
    $senha = $_POST["senha"];
    $endereco = $_POST["endereco"];
    $telefone1 = $_POST["telefone1"];
    $telefone2 = $_POST["telefone2"];


    $sql = "INSERT INTO cliente
            (nome_cliente, cpf_cliente, senha_cliente, endereco_cliente, telefone_um, telefone_dois)
            VALUES (?, ?, ?, ?, ?, ?)";


    $stmt = $conexao->prepare($sql);


    $stmt->bind_param(
        "ssssss",
        $nome,
        $cpf,
        $senha,
        $endereco,
        $telefone1,
        $telefone2
    );


    if ($stmt->execute()) {

        echo '<div class="sucesso">
                Cliente cadastrado com sucesso!
              </div>';

    } else {

        echo '<div class="sucesso">
                Erro ao cadastrar cliente: ' . $stmt->error . '
              </div>';

    }

}


/* =======================================================
   CADASTRO DE CARRO
   ======================================================= */

if (isset($_POST["cadastrar_carro"])) {

    $tipo = $_POST["tipo"];
    $placa = $_POST["placa"];
    $cpfproprietario = $_POST["cpfproprietario"];
    $codavaria = $_POST["codavaria"];
    $status_conserto = $_POST["status_conserto"];


    /*
       O status está sendo recebido,
       mas nesta versão o cadastro continua
       usando os quatro campos originais do carro.
    */

    $sql = "INSERT INTO carro
            (tipo_carro, placa_carro, cpf_proprietario, codigo_avaria)
            VALUES (?, ?, ?, ?)";


    $stmt = $conexao->prepare($sql);


    $stmt->bind_param(
        "ssss",
        $tipo,
        $placa,
        $cpfproprietario,
        $codavaria
    );


    if ($stmt->execute()) {

        echo '<div class="sucesso">
                Carro cadastrado com sucesso!
              </div>';

    } else {

        echo '<div class="sucesso">
                Erro ao cadastrar carro: ' . $stmt->error . '
              </div>';

    }

}


/* =======================================================
   CADASTRO DE AVARIA
   ======================================================= */

if (isset($_POST["cadastrar_avaria"])) {

    $codigo = $_POST["codigo"];
    $descricao = $_POST["descricao"];


    $sql = "INSERT INTO avaria
            (codigo_avaria, descricao_avaria)
            VALUES (?, ?)";


    $stmt = $conexao->prepare($sql);


    $stmt->bind_param(
        "ss",
        $codigo,
        $descricao
    );


    if ($stmt->execute()) {

        echo '<div class="sucesso">
                Avaria cadastrada com sucesso!
              </div>';

    } else {

        echo '<div class="sucesso">
                Erro ao cadastrar avaria: ' . $stmt->error . '
              </div>';

    }

}


/* =======================================================
   MENU
   ======================================================= */

if (isset($_POST["acao"])) {

    $acao = $_POST["acao"];


    /* ===================================================
       CLIENTES
       =================================================== */

    if ($acao == "clientes") {

?>


<div class="caixa">

    <h2>Cadastro de Cliente</h2>


    <form method="POST" class="formulario">

        <label>Nome:</label>

        <input type="text"
               name="nome"
               required>


        <label>CPF:</label>

        <input type="text"
               name="cpf"
               required>


        <label>Senha:</label>

        <input type="text"
               name="senha"
               required>


        <label>Endereço:</label>

        <input type="text"
               name="endereco"
               required>


        <label>Telefone 1:</label>

        <input type="text"
               name="telefone1"
               required>


        <label>Telefone 2:</label>

        <input type="text"
               name="telefone2"
               required>


        <button type="submit"
                name="cadastrar_cliente"
                class="botao">

            Cadastrar cliente

        </button>

    </form>

</div>


<?php


        /*
           LISTA DE CLIENTES
        */


        $resultado = $conexao->query(
            "SELECT * FROM cliente"
        );


?>


<div class="caixa">

    <h2>Clientes cadastrados</h2>


    <div class="tabela-container">

        <table>

            <tr>

                <th>Nome</th>
                <th>CPF</th>
                <th>Endereço</th>
                <th>Telefone 1</th>
                <th>Telefone 2</th>

            </tr>


<?php

while ($cliente = $resultado->fetch_assoc()) {

?>


            <tr>

                <td>
                    <?php echo $cliente["nome_cliente"]; ?>
                </td>

                <td>
                    <?php echo $cliente["cpf_cliente"]; ?>
                </td>

                <td>
                    <?php echo $cliente["endereco_cliente"]; ?>
                </td>

                <td>
                    <?php echo $cliente["telefone_um"]; ?>
                </td>

                <td>
                    <?php echo $cliente["telefone_dois"]; ?>
                </td>

            </tr>


<?php

}

?>


        </table>

    </div>

</div>


<?php


    }


    /* ===================================================
       CARROS
       =================================================== */

    elseif ($acao == "carros") {

?>


<div class="caixa">

    <h2>Cadastro de Carro</h2>


    <form method="POST" class="formulario">


        <label>Tipo do carro:</label>

        <input type="text"
               name="tipo"
               required>


        <label>Placa:</label>

        <input type="text"
               name="placa"
               required>


        <label>CPF do proprietário:</label>

        <input type="text"
               name="cpfproprietario"
               required>


        <label>Código da avaria:</label>

        <input type="text"
               name="codavaria"
               required>


        <label>Status do conserto:</label>

        <select name="status_conserto">

            <option value="Aguardando revisão">
                Aguardando revisão
            </option>

            <option value="Em conserto">
                Em conserto
            </option>

            <option value="Pronto">
                Pronto
            </option>

            <option value="Aguardando fornecedor">
                Aguardando fornecedor
            </option>

            <option value="Aguardando informações">
                Aguardando informações
            </option>

            <option value="Ordens">
                Ordens
            </option>

        </select>


        <button type="submit"
                name="cadastrar_carro"
                class="botao">

            Cadastrar carro

        </button>

    </form>

</div>


<?php


        /*
           LISTA DE CARROS
        */


        $resultado = $conexao->query(
            "SELECT * FROM carro"
        );


?>


<div class="caixa">

    <h2>Carros cadastrados</h2>


    <div class="tabela-container">

        <table>

            <tr>

                <th>Tipo</th>
                <th>Placa</th>
                <th>CPF do proprietário</th>
                <th>Código da avaria</th>

            </tr>


<?php

while ($carro = $resultado->fetch_assoc()) {

?>


            <tr>

                <td>
                    <?php echo $carro["tipo_carro"]; ?>
                </td>

                <td>
                    <?php echo $carro["placa_carro"]; ?>
                </td>

                <td>
                    <?php echo $carro["cpf_proprietario"]; ?>
                </td>

                <td>
                    <?php echo $carro["codigo_avaria"]; ?>
                </td>

            </tr>


<?php

}

?>


        </table>

    </div>

</div>


<?php


    }


    /* ===================================================
       AVARIAS
       =================================================== */

    elseif ($acao == "avarias") {

?>


<div class="caixa">

    <h2>Cadastro de Avaria</h2>


    <form method="POST" class="formulario">


        <label>Código da avaria:</label>

        <input type="text"
               name="codigo"
               required>


        <label>Descrição da avaria:</label>

        <textarea name="descricao"
                  required></textarea>


        <button type="submit"
                name="cadastrar_avaria"
                class="botao">

            Cadastrar avaria

        </button>

    </form>

</div>


<?php


        /*
           LISTA DE AVARIAS
        */


        $resultado = $conexao->query(
            "SELECT * FROM avaria"
        );


?>


<div class="caixa">

    <h2>Avarias cadastradas</h2>


    <div class="tabela-container">

        <table>

            <tr>

                <th>Código</th>
                <th>Descrição</th>

            </tr>


<?php

while ($avaria = $resultado->fetch_assoc()) {

?>


            <tr>

                <td>
                    <?php echo $avaria["codigo_avaria"]; ?>
                </td>

                <td>
                    <?php echo $avaria["descricao_avaria"]; ?>
                </td>

            </tr>


<?php

}

?>


        </table>

    </div>

</div>


<?php


    }


    /* ===================================================
       CADASTRO COMPLETO
       =================================================== */

    elseif ($acao == "cadcompleto") {

?>


<div class="caixa">

    <h2>Cadastro completo</h2>


    <div class="cadastro-completo">

        <table>

            <tr>

                <th>Cliente</th>
                <th>CPF</th>
                <th>Carro</th>
                <th>Placa</th>
                <th>Avaria</th>
                <th>Descrição</th>

            </tr>


<?php


        $sql = "SELECT
                    cliente.nome_cliente,
                    cliente.cpf_cliente,
                    carro.tipo_carro,
                    carro.placa_carro,
                    avaria.codigo_avaria,
                    avaria.descricao_avaria

                FROM carro

                INNER JOIN cliente
                    ON carro.cpf_proprietario = cliente.cpf_cliente

                INNER JOIN avaria
                    ON carro.codigo_avaria = avaria.codigo_avaria";


        $resultado = $conexao->query($sql);


        while ($dados = $resultado->fetch_assoc()) {

?>


            <tr>

                <td>
                    <?php echo $dados["nome_cliente"]; ?>
                </td>

                <td>
                    <?php echo $dados["cpf_cliente"]; ?>
                </td>

                <td>
                    <?php echo $dados["tipo_carro"]; ?>
                </td>

                <td>
                    <?php echo $dados["placa_carro"]; ?>
                </td>

                <td>
                    <?php echo $dados["codigo_avaria"]; ?>
                </td>

                <td>
                    <?php echo $dados["descricao_avaria"]; ?>
                </td>

            </tr>


<?php

        }

?>


        </table>

    </div>

</div>


<?php


    }


    /* ===================================================
       ACOMPANHAMENTO
       =================================================== */

    elseif ($acao == "acompanhamento") {

?>


<div class="caixa">

    <h2>Controle dos consertos</h2>


    <div id="mensagem"
         class="sucesso"
         style="display: none;">

        Dados atualizados com sucesso!

    </div>


    <div class="tabela-container">

        <table>

            <tr>

                <th>Cliente</th>
                <th>Placa</th>
                <th>Status do conserto</th>
                <th>Valor previsto</th>
                <th>Data prevista</th>
                <th>Ação</th>

            </tr>


            <!-- CLIENTE 1 -->

            <tr>

                <td>
                    Alan
                </td>

                <td>
                    124578E4
                </td>

                <td>

                    <select>

                        <option>
                            Aguardando revisão
                        </option>

                        <option selected>
                            Em conserto
                        </option>

                        <option>
                            Pronto
                        </option>

                        <option>
                            Aguardando fornecedor
                        </option>

                        <option>
                            Aguardando informações
                        </option>

                        <option>
                            Ordens
                        </option>

                    </select>

                </td>

                <td>

                    <input type="text"
                           value="1500,00">

                </td>

                <td>

                    <input type="date"
                           value="2026-10-05">

                </td>

                <td>

                    <button type="button"
                            class="botao"
                            onclick="atualizar()">

                        Atualizar

                    </button>

                </td>

            </tr>


            <!-- CLIENTE 2 -->

            <tr>

                <td>
                    Ana de Souza
                </td>

                <td>
                    ADICIONAR
                </td>

                <td>

                    <select>

                        <option>
                            Aguardando revisão
                        </option>

                        <option>
                            Em conserto
                        </option>

                        <option>
                            Pronto
                        </option>

                        <option selected>
                            Aguardando fornecedor
                        </option>

                        <option>
                            Aguardando informações
                        </option>

                        <option>
                            Ordens
                        </option>

                    </select>

                </td>

                <td>

                    <input type="text"
                           value="850,00">

                </td>

                <td>

                    <input type="date"
                           value="2026-10-10">

                </td>

                <td>

                    <button type="button"
                            class="botao"
                            onclick="atualizar()">

                        Atualizar

                    </button>

                </td>

            </tr>


            <!-- CLIENTE 3 -->

            <tr>

                <td>
                    Aninha
                </td>

                <td>
                    ADICIONAR
                </td>

                <td>

                    <select>

                        <option>
                            Aguardando revisão
                        </option>

                        <option>
                            Em conserto
                        </option>

                        <option selected>
                            Pronto
                        </option>

                        <option>
                            Aguardando fornecedor
                        </option>

                        <option>
                            Aguardando informações
                        </option>

                        <option>
                            Ordens
                        </option>

                    </select>

                </td>

                <td>

                    <input type="text"
                           value="2300,00">

                </td>

                <td>

                    <input type="date"
                           value="2026-09-30">

                </td>

                <td>

                    <button type="button"
                            class="botao"
                            onclick="atualizar()">

                        Atualizar

                    </button>

                </td>

            </tr>


            <!-- CLIENTE 4 -->

            <tr>

                <td>
                    Joana
                </td>

                <td>
                    ED8976G43D
                </td>

                <td>

                    <select>

                        <option>
                            Aguardando revisão
                        </option>

                        <option>
                            Em conserto
                        </option>

                        <option>
                            Pronto
                        </option>

                        <option>
                            Aguardando fornecedor
                        </option>

                        <option selected>
                            Aguardando informações
                        </option>

                        <option>
                            Ordens
                        </option>

                    </select>

                </td>

                <td>

                    <input type="text"
                           value="1200,00">

                </td>

                <td>

                    <input type="date"
                           value="2026-10-15">

                </td>

                <td>

                    <button type="button"
                            class="botao"
                            onclick="atualizar()">

                        Atualizar

                    </button>

                </td>

            </tr>


        </table>

    </div>

</div>


<script>

function atualizar() {

    document.getElementById("mensagem").style.display = "block";

}

</script>


<?php

    }

}

?>

</body>

</html>