<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="utf-8">
    <title>Cliente</title>
     <style>
        body {
            background-color: #d6d6d6;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            color: #333;
        }
        .topo {
            background-color: #333;
            color: white;
            padding: 20px 40px;
            border-bottom: 5px solid #e87500;
            position: relative;
        }
        .topo h1 {
            margin: 0;
            font-size: 25px;
        }
        .sair {
            position: absolute;
            right: 40px;
            top: 20px;

            padding: 9px 20px;

            background-color: #e87500;
            color: white;

            text-decoration: none;
            border-radius: 3px;
        }

        .sair:hover {
            background-color: #cf6700;
        }
        h2 {
            margin-top: 0;
            color: #333;
            margin-bottom: 25px;
        }
        label {
            display: block;
            margin-top: 15px;
            margin-bottom: 5px;
            color: #333;
        }
        .caixa {
            background-color: white;

            padding: 30px;

            width: 850px;
            max-width: 90%;

            margin: 30px auto;

            box-sizing: border-box;

            box-shadow: 0 2px 8px #999;

            border-top: 4px solid #e87500;
        }

        .verde{
            color: limegreen;
        }

    </style>
</head>

<body>

 <div class="topo">
    <h1>Área da Joana</h1>
    <a href="login.php" class="sair">Sair</a>
</div>

<div class="caixa">
    <h2>Dados principais</h2>
    <label>CPF: 4549846516</label>
    <label>Veículo: BYD Dolphin Mini Azul 2025</label>
    <label>Placa: ED8976G43D</label>
</div>

<div class="caixa">
    <h2>Status do veículo<h2>
    <div class="verde">
        <p>Aguardando fornecedor</p>
    </div>
</h2>


<div class="caixa">
    <h2>Datas e valores previstos</h2>
    <label>Data prevista para a entrega: 10/12/2026</label>
    <label>Valor previsto do conserto: R$235,14</label>
</div>



</body>
</html>