<?php

$host = "sql111.infinityfree.com";
$usuario = "if0_43037895";
$senha = "pdtiDsRSek53M9";
$banco = "if0_43037895_db_autoline";

$conexao = new mysqli($host, $usuario, $senha, $banco);

if ($conexao->connect_error) {
    die("Erro na conexão: " . $conexao->connect_error);
}

?>