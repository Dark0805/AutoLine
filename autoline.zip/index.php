<!DOCTYPE html>
<html lang="pt-br"> 
    <head>
        <meta charset="utf-8">
        <title>Login</title>
        <style> 
        	body { background-image: url("carro.jpeg"); background-size: cover;
            background-position: center; background-repeat: no-repeat;
            min-height: 100vh; font-family: Arial, sans-serif; margin: 0; padding: 0; } 
    		.login { width: 320px; margin: 100px auto; background-color: white; padding: 30px; border-top: 5px solid #e87500; box-shadow: 0 2px 8px #999; } 
    		h2 { text-align: center; color: #333; margin-bottom: 25px; } 
    		label { display: block; margin-top: 15px; margin-bottom: 5px; color: #333; } 
    		input { width: 100%; padding: 9px; box-sizing: border-box; border: 1px solid #aaa; border-radius: 3px; } 
    		input:focus { border-color: #e87500; outline: none; } 
    		button { width: 100%; margin-top: 25px; padding: 10px; background-color: #e87500; color: white; border: none; border-radius: 3px; cursor: pointer; } 
    		button:hover { background-color: #cf6700; } .erro { color: #d35400; text-align: center; margin-top: 15px; } 
    	</style>
    </head>

    <body>
    	<div class="login">
    		<h1>Área de login</h1>

        <form action="" method="post">
            CPF:
            <input type="text" name="CPF"><br>

            Senha:
            <input type="password" name="Senha"><br>

            <button type="submit">Entrar</button>
        </form>

        <?php

        if (isset($_POST["CPF"]) && isset($_POST["Senha"])) {

            $usuario = $_POST["CPF"];
            $senha = $_POST["Senha"];

            if ($senha == 123 and $usuario == 123456789):
                header("Location: funcionario.php");
                exit;

            elseif ($senha == 1234 and $usuario == 123456789):
                header("Location: cliente.php");
                exit;

            elseif ($senha == 12345 and $usuario == 123456789):
                header("Location: adm.php");
                exit;

            else:
                echo "A senha ou o usuário estão errados, tente novamente.";
            endif;

        }

        ?>
       </div>

    </body>
</html>