<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <title>Cadastro de Funcionários</title>

    <style>
/*FUNDO*/
        body {
            background-color: #d6d6d6;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
/*CABEÇALHO*/

        .topo {
            background-color: #333;
            color: white;
            padding: 20px 40px;
            border-bottom: 5px solid #e87500;
        }

/*TÍTULO 1*/

        .topo h1 {
            margin: 0;
            font-size: 25px;
        }

/*FAZ OS ELEMENTOS CITADOS FICAREM LADO A LADO*/

        .conteudo {
            display: flex;
            gap: 30px;
            width: 850px;
            margin: 50px auto;
        }

/*CAIXA QUE FICA NO CENTRO*/
        .caixa {
            background-color: white;
            padding: 30px;
            width: 50%;
            box-sizing: border-box;
            box-shadow: 0 2px 8px #999;
            border-top: 4px solid #e87500;
        }


/*TÍTULO 2*/
        h2 {
            margin-top: 0;
            color: #333;
            margin-bottom: 25px;
        }

/*LABEL*/
        label {
            display: block;
            margin-top: 15px;
            margin-bottom: 5px;
            color: #333;
        }

        input,
        select {
            width: 100%;
            padding: 9px;
            box-sizing: border-box;
            border: 1px solid #aaa;
            border-radius: 3px;
        }

        input:focus,
        select:focus {
            outline: none;
            border-color: #e87500;
        }

        .botao {
            width: 100%;
            padding: 10px;
            margin-top: 25px;
            background-color: #e87500;
            color: white;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            font-size: 15px;
        }

        .botao:hover {
            background-color: #cf6700;
        }

        .dados {
            line-height: 1.8;
            color: #444;
        }

        .dados strong {
            color: #333;
        }

        .sair {
            position: absolute;
            right: 40px;
            top: 20px;
            padding: 9px 20px;
            background-color: #e87500;
            color: white;
            text-decoration: none;
            border-radius: 3px;
        }

        .sair:hover {
            background-color: #cf6700;
        }

    </style>

</head>

<body>

    <div class="topo">

        <h1>Área do Administrador</h1>

        <a href="login.php" class="sair">Voltar</a>

    </div>


    <div class="conteudo">

        <!-- CADASTRO -->

        <div class="caixa">

            <h2>Cadastrar funcionário</h2>

            <form action="" method="post">

                <label>Nome:</label>
                <input type="text" name="nome">

                <label>CPF:</label>
                <input type="text" name="cpf">

                <label>Senha:</label>
                <input type="password" name="senha">

                <label>Cargo:</label>
                <input type="text" name="cargo">

                <label>Permissão:</label>

                <select name="permissao">
                    <option value="nível 1">Acesso à 1 veículo</option>
                    <option value="nível 2">Acesso à alguns veículos</option>
                    <option value="nível 3">Acesso à todos os veículos</option>
                    <option value="nível 4">Acesso à todos os veículos e clientes</option>
                </select>

                <button type="submit" class="botao">
                    Cadastrar
                </button>

            </form>

        </div>


        <!-- ÚLTIMO CADASTRO -->

        <div class="caixa">

            <h2>Último cadastro</h2>

            <?php

            if (isset($_POST["nome"])) {

                $nome = $_POST["nome"];
                $cpf = $_POST["cpf"];
                $senha = $_POST["senha"];
                $cargo = $_POST["cargo"];
                $permissao = $_POST["permissao"];

            ?>

                <div class="dados">

                    <strong>Nome:</strong>
                    <?php echo $nome; ?>
                    <br>

                    <strong>CPF:</strong>
                    <?php echo $cpf; ?>
                    <br>

                    <strong>Senha:</strong>
                    <?php echo $senha; ?>
                    <br>

                    <strong>Cargo:</strong>
                    <?php echo $cargo; ?>
                    <br>

                    <strong>Permissão:</strong>
                    <?php echo $permissao; ?>

                </div>

            <?php

            } else {

                echo "Nenhum funcionário cadastrado ainda.";

            }

            ?>

        </div>

    </div>

</body>

</html>
